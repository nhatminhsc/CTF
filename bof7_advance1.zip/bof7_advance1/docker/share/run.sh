#!/bin/sh

cd /server
socat tcp-listen:9999,fork,reuseaddr exec:./bypass 2>/dev/null