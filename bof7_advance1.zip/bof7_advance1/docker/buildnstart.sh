#!/bin/sh

sudo docker build . -t ret2libc
sudo docker run --rm -p 9999:9999 -it ret2libc