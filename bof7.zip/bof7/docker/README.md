To build docker, run:
```
docker build . -t bof7
```

To run image, run:
```
docker run --rm -p 9993:9993 -it bof7
```