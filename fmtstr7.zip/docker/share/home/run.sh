#!/bin/sh

socat tcp-listen:9997,fork,reuseaddr exec:./fmtstr7 2>/dev/null