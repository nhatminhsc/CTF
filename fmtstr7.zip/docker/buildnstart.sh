#!/bin/sh

sudo apt install docker.io
sudo docker build . -t fmtstr7 && sudo docker run -d --rm -p 9997:9997 -it fmtstr7